
$(function(){

    $('#changetabbutton2').click(function(e){
        e.preventDefault();
        $('#mytabs a[href="#second"]').tab('show');

    })

});

$(function(){

    $('#changetabbutton3').click(function(e){
        e.preventDefault();
        $('#mytabs a[href="#third"]').tab('show');
    })

});
$(function(){

    $('#changetabbutton4').click(function(e){
        e.preventDefault();
        $('#mytabs a[href="#third"]').tab('show');
    })

});
$(function(){

    $('#changetabbutton5').click(function(e){
        e.preventDefault();
        $('#mytabs a[href="#third"]').tab('show');
    })

});
$(function(){

    $('#changetabbutton6').click(function(e){
        e.preventDefault();
        $('#mytabs a[href="#third"]').tab('show');
    })

});



$(function(){

    $('#changetabbutton1').click(function(e){
        e.preventDefault();
        $('#mytabs a[href="#first"]').tab('show');
    })

});


// BACK BUTTON

$(function(){

    $('#backtabbutton1').click(function(e){
        e.preventDefault();
        $('#mytabs a[href="#first"]').tab('show');
    })

});

$(function(){

    $('#backtabbutton2').click(function(e){
        e.preventDefault();
        $('#mytabs a[href="#second"]').tab('show');
    })

});









